#ifndef DEF_EVA
#define DEF_EVA 1

#include "CGP.h"

using namespace std;

class Evaluator {
public:
	double evaluate(CGP* cgp, vector<int> g);
};

#endif
